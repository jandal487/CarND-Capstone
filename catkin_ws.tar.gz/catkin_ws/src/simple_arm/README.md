# simple_arm_01
A mini-project for RoboND's ROS Basics Module, Lesson 02.

```
